console.log("TEACHER JS FILE LOADED");

document.addEventListener("DOMContentLoaded", function () {
    // =========================================
    // API CONFIGURATION
    // =========================================

    const API_BASE_URL =
        "https://a6ivi274ul.execute-api.ap-south-1.amazonaws.com/prod";


    // =========================================
    // LOGIN PROTECTION
    // =========================================

    const role =
        localStorage.getItem("maktabRole");

    const username =
        localStorage.getItem("maktabUsername");


    if (role !== "teacher") {

        window.location.href = "login.html";

        return;
    }


    // =========================================
    // SHOW TEACHER NAME
    // =========================================

    const teacherName =
        document.getElementById("teacherName");

    if (teacherName && username) {
        teacherName.textContent = username;
    }


    // =========================================
    // ELEMENTS
    // =========================================

    const classSelect =
        document.getElementById("classSelect");

    const dateInput =
        document.getElementById("attendanceDate");

    const loadStudentsButton =
        document.getElementById("loadStudentsButton");

    const attendanceCard =
        document.getElementById("attendanceCard");

    const logoutButton =
        document.getElementById("logoutButton");


    // =========================================
    // CHECK REQUIRED ELEMENTS
    // =========================================

    if (!classSelect ||
        !dateInput ||
        !loadStudentsButton ||
        !attendanceCard ||
        !logoutButton) {

        console.error(
            "Teacher page elements are missing."
        );

        return;
    }


    // =========================================
    // TODAY'S DATE
    // =========================================

    const today =
        new Date()
            .toISOString()
            .split("T")[0];

    dateInput.value = today;


    // =========================================
    // LOGOUT
    // =========================================

    logoutButton.addEventListener(
        "click",
        function () {

            localStorage.removeItem(
                "maktabUsername"
            );

            localStorage.removeItem(
                "maktabRole"
            );

            localStorage.removeItem(
                "maktabToken"
            );

            window.location.href =
                "login.html";
        }
    );


    // =========================================
    // LOAD STUDENTS BUTTON
    // =========================================

    loadStudentsButton.addEventListener(
        "click",
        loadStudents
    );


    // =========================================
    // LOAD STUDENTS
    // =========================================

    async function loadStudents() {

        const selectedClass =
            classSelect.value;

        const selectedDate =
            dateInput.value;


        console.log(
            "Selected Class:",
            selectedClass
        );

        console.log(
            "Selected Date:",
            selectedDate
        );


        // =====================================
        // VALIDATION
        // =====================================

        if (!selectedClass) {

            alert(
                "Please select a class."
            );

            return;
        }


        if (!selectedDate) {

            alert(
                "Please select a date."
            );

            return;
        }


        // =====================================
        // LOADING UI
        // =====================================

        attendanceCard.innerHTML = `

            <div class="empty-state">

                <div class="empty-icon">
                    ⏳
                </div>

                <h3>
                    Loading students...
                </h3>

                <p>
                    Please wait.
                </p>

            </div>

        `;


        loadStudentsButton.disabled = true;

        loadStudentsButton.textContent =
            "Loading...";


        try {

            // =================================
            // STEP 1
            // GET STUDENTS
            // =================================

            const studentsUrl =
                `${API_BASE_URL}/students?class=${encodeURIComponent(
                    selectedClass
                )}`;


            console.log(
                "Students API URL:",
                studentsUrl
            );


            const studentsResponse =
                await fetch(
                    studentsUrl
                );


            console.log(
                "Students API Status:",
                studentsResponse.status
            );


            if (!studentsResponse.ok) {

                throw new Error(
                    `Students API returned ${studentsResponse.status}`
                );
            }


            const studentsData =
                await studentsResponse.json();


            console.log(
                "Students API Response:",
                studentsData
            );


            if (!studentsData.success) {

                throw new Error(
                    studentsData.message ||
                    "Unable to load students."
                );
            }


            const students =
                studentsData.students || [];


            console.log(
                "Students Found:",
                students.length
            );


            // =================================
            // NO STUDENTS
            // =================================

            if (!students.length) {

                attendanceCard.innerHTML = `

                    <div class="empty-state">

                        <div class="empty-icon">
                            👨‍🎓
                        </div>

                        <h3>
                            No students found
                        </h3>

                        <p>
                            No students are available
                            for ${escapeHtml(
                                selectedClass
                            )}.
                        </p>

                    </div>

                `;

                return;
            }


            // =================================
            // IMPORTANT:
            // DISPLAY STUDENTS IMMEDIATELY
            // =================================

            displayStudents(
                students,
                [],
                selectedClass,
                selectedDate
            );


            // =================================
            // STEP 2
            // GET EXISTING ATTENDANCE
            // =================================

            const attendanceUrl =
                `${API_BASE_URL}/attendance?class=${encodeURIComponent(
                    selectedClass
                )}&date=${encodeURIComponent(
                    selectedDate
                )}`;


            console.log(
                "Attendance API URL:",
                attendanceUrl
            );


            try {

                const attendanceResponse =
                    await fetch(
                        attendanceUrl
                    );


                console.log(
                    "Attendance API Status:",
                    attendanceResponse.status
                );


                if (!attendanceResponse.ok) {

                    console.warn(
                        "Attendance API failed. Students are still displayed."
                    );

                    return;
                }


                const attendanceData =
                    await attendanceResponse.json();


                console.log(
                    "Attendance API Response:",
                    attendanceData
                );


                const attendanceRecords =
                    attendanceData.records || [];


                // =================================
                // DISPLAY WITH EXISTING ATTENDANCE
                // =================================

                displayStudents(
                    students,
                    attendanceRecords,
                    selectedClass,
                    selectedDate
                );

            }

            catch (attendanceError) {

                console.warn(
                    "Attendance API error:",
                    attendanceError
                );

                // Students already displayed.
            }

        }

        catch (error) {

            console.error(
                "Load Students Error:",
                error
            );


            attendanceCard.innerHTML = `

                <div class="empty-state">

                    <div class="empty-icon">
                        ❌
                    </div>

                    <h3>
                        Unable to load students
                    </h3>

                    <p>
                        ${escapeHtml(
                            error.message
                        )}
                    </p>

                </div>

            `;

        }

        finally {

            loadStudentsButton.disabled =
                false;

            loadStudentsButton.textContent =
                "Load Students";

        }

    }


    // =========================================
    // DISPLAY STUDENTS
    // =========================================

    function displayStudents(
        students,
        attendanceRecords,
        selectedClass,
        selectedDate
    ) {

        // =====================================
        // ATTENDANCE MAP
        // =====================================

        const attendanceMap =
            new Map();


        attendanceRecords.forEach(
            function (record) {

                attendanceMap.set(
                    record.student_id,
                    record.status
                );

            }
        );


        // =====================================
        // CREATE ROWS
        // =====================================

        let rows = "";


        students.forEach(
            function (student, index) {

                const existingStatus =
                    attendanceMap.get(
                        student.student_id
                    ) || "";


                rows += `

                    <tr
                        data-student-id="${escapeHtml(
                            student.student_id
                        )}"
                    >

                        <td>
                            ${index + 1}
                        </td>

                        <td>
                            ${escapeHtml(
                                student.form_no || "-"
                            )}
                        </td>

                        <td>
                            ${escapeHtml(
                                student.student_name
                            )}
                        </td>

                        <td>

                            <div class="attendance-buttons">

                                <button
                                    type="button"
                                    class="attendance-btn present-btn ${
                                        existingStatus ===
                                        "Present"
                                            ? "selected"
                                            : ""
                                    }"
                                    data-status="Present"
                                >
                                    Present
                                </button>


                                <button
                                    type="button"
                                    class="attendance-btn absent-btn ${
                                        existingStatus ===
                                        "Absent"
                                            ? "selected"
                                            : ""
                                    }"
                                    data-status="Absent"
                                >
                                    Absent
                                </button>

                            </div>

                        </td>

                    </tr>

                `;

            }
        );


        // =====================================
        // ATTENDANCE CARD
        // =====================================

        attendanceCard.innerHTML = `

            <div class="attendance-header">

                <div>

                    <h3>
                        ${escapeHtml(
                            selectedClass
                        )}
                    </h3>

                    <p>
                        Attendance Date:
                        ${escapeHtml(
                            selectedDate
                        )}
                    </p>

                </div>


                <div class="attendance-summary">

                    <div class="summary-item">

                        <span>
                            Students
                        </span>

                        <strong id="studentCount">
                            ${students.length}
                        </strong>

                    </div>


                    <div class="summary-item">

                        <span>
                            Present
                        </span>

                        <strong id="presentCount">
                            0
                        </strong>

                    </div>


                    <div class="summary-item">

                        <span>
                            Absent
                        </span>

                        <strong id="absentCount">
                            0
                        </strong>

                    </div>

                </div>

            </div>


            <div class="table-container">

                <table>

                    <thead>

                        <tr>

                            <th>
                                #
                            </th>

                            <th>
                                Form No.
                            </th>

                            <th>
                                Student Name
                            </th>

                            <th>
                                Attendance
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        ${rows}

                    </tbody>

                </table>

            </div>


            <div class="save-attendance-container">

                <button
                    type="button"
                    id="saveAttendanceButton"
                    class="primary-button save-button"
                >
                    💾 Save Attendance
                </button>

            </div>

        `;


        // =====================================
        // ATTENDANCE BUTTONS
        // =====================================

        const attendanceButtons =
            attendanceCard.querySelectorAll(
                ".attendance-btn"
            );


        attendanceButtons.forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function () {

                        const row =
                            button.closest("tr");


                        const buttons =
                            row.querySelectorAll(
                                ".attendance-btn"
                            );


                        buttons.forEach(
                            function (btn) {

                                btn.classList.remove(
                                    "selected"
                                );

                            }
                        );


                        button.classList.add(
                            "selected"
                        );


                        updateCounts();

                    }
                );

            }
        );


        // =====================================
        // SAVE BUTTON
        // =====================================

        const saveButton =
            document.getElementById(
                "saveAttendanceButton"
            );


        if (saveButton) {

            saveButton.addEventListener(
                "click",
                function () {

                    saveAttendance(
                        students,
                        selectedClass,
                        selectedDate
                    );

                }
            );

        }


        // =====================================
        // INITIAL COUNTS
        // =====================================

        updateCounts();

    }


    // =========================================
    // UPDATE COUNTS
    // =========================================

    function updateCounts() {

        const selectedPresent =
            attendanceCard.querySelectorAll(
                ".present-btn.selected"
            ).length;


        const selectedAbsent =
            attendanceCard.querySelectorAll(
                ".absent-btn.selected"
            ).length;


        const presentCount =
            document.getElementById(
                "presentCount"
            );


        const absentCount =
            document.getElementById(
                "absentCount"
            );


        if (presentCount) {

            presentCount.textContent =
                selectedPresent;

        }


        if (absentCount) {

            absentCount.textContent =
                selectedAbsent;

        }

    }


    // =========================================
    // SAVE ATTENDANCE
    // =========================================

    async function saveAttendance(
        students,
        selectedClass,
        selectedDate
    ) {

        const saveButton =
            document.getElementById(
                "saveAttendanceButton"
            );


        const rows =
            attendanceCard.querySelectorAll(
                "tbody tr"
            );


        const attendance = [];


        // =====================================
        // COLLECT ATTENDANCE
        // =====================================

        rows.forEach(
            function (row) {

                const studentId =
                    row.dataset.studentId;


                const selectedButton =
                    row.querySelector(
                        ".attendance-btn.selected"
                    );


                if (!selectedButton) {
                    return;
                }


                const student =
                    students.find(
                        function (item) {

                            return item.student_id ===
                                studentId;

                        }
                    );


                if (!student) {
                    return;
                }


                attendance.push({

                    student_id:
                        student.student_id,

                    student_name:
                        student.student_name,

                    status:
                        selectedButton.dataset.status

                });

            }
        );


        // =====================================
        // VALIDATION
        // =====================================

        if (!attendance.length) {

            alert(
                "Please mark attendance for at least one student."
            );

            return;
        }


        if (
            attendance.length !==
            students.length
        ) {

            const confirmSave =
                confirm(
                    "Some students have not been marked. Do you want to continue?"
                );


            if (!confirmSave) {
                return;
            }

        }


        // =====================================
        // SAVE
        // =====================================

        saveButton.disabled = true;

        saveButton.textContent =
            "Saving...";


        try {

            const response =
                await fetch(
                    `${API_BASE_URL}/attendance`,
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({

                            class_name:
                                selectedClass,

                            date:
                                selectedDate,

                            teacher:
                                username,

                            attendance:
                                attendance

                        })

                    }
                );


            const data =
                await response.json();


            console.log(
                "Save Attendance Response:",
                data
            );


            if (!response.ok) {

                throw new Error(
                    data.message ||
                    `API returned ${response.status}`
                );

            }


            if (!data.success) {

                throw new Error(
                    data.message ||
                    "Attendance could not be saved."
                );

            }


            alert(
                "Attendance saved successfully! ✅"
            );


            // =================================
            // RELOAD
            // =================================

            await loadStudents();

        }

        catch (error) {

            console.error(
                "Save Attendance Error:",
                error
            );


            alert(
                "Unable to save attendance.\n\n" +
                error.message
            );

        }

        finally {

            saveButton.disabled =
                false;

            saveButton.textContent =
                "💾 Save Attendance";

        }

    }


    // =========================================
    // HTML ESCAPE
    // =========================================

    function escapeHtml(value) {

        const div =
            document.createElement("div");

        div.textContent =
            value ?? "";

        return div.innerHTML;

    }

});