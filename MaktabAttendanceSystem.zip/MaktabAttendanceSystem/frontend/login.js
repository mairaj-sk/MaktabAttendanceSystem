document.addEventListener("DOMContentLoaded", function () {

    // =========================================
    // API CONFIGURATION
    // =========================================

    const API_BASE_URL =
        "https://a6ivi274ul.execute-api.ap-south-1.amazonaws.com/prod";


    // =========================================
    // ELEMENTS
    // =========================================

    const loginForm =
        document.getElementById("loginForm");

    const usernameInput =
        document.getElementById("username");

    const passwordInput =
        document.getElementById("password");

    const roleInput =
        document.getElementById("role");

    const loginButton =
        document.getElementById("loginButton");

    const loginMessage =
        document.getElementById("loginMessage");


    // =========================================
    // LOGIN FORM
    // =========================================

    loginForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            const username =
                usernameInput.value.trim();

            const password =
                passwordInput.value;

            const role =
                roleInput.value;


            // =====================================
            // VALIDATION
            // =====================================

            if (!username) {

                showMessage(
                    "Please enter your username.",
                    "error"
                );

                return;
            }


            if (!password) {

                showMessage(
                    "Please enter your password.",
                    "error"
                );

                return;
            }


            if (!role) {

                showMessage(
                    "Please select your role.",
                    "error"
                );

                return;
            }


            // =====================================
            // LOADING
            // =====================================

            loginButton.disabled = true;

            loginButton.textContent =
                "Logging in...";

            showMessage("", "");


            try {

                // =================================
                // LOGIN API
                // =================================

                const response =
                    await fetch(
                        `${API_BASE_URL}/login`,
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body: JSON.stringify({
                                username: username,
                                password: password,
                                role: role
                            })
                        }
                    );


                // =================================
                // RESPONSE
                // =================================

                const data =
                    await response.json();


                console.log(
                    "Login API Response:",
                    data
                );


                // =================================
                // HANDLE API ERROR
                // =================================

                if (!response.ok) {

                    throw new Error(
                        data.message ||
                        "Login failed."
                    );

                }


                // =================================
                // LOGIN SUCCESS
                // =================================

                if (
                    data.success === true ||
                    data.success === "true"
                ) {

                    // Save login information

                    localStorage.setItem(
                        "maktabUsername",
                        username
                    );


                    localStorage.setItem(
                        "maktabRole",
                        role
                    );


                    // Optional token/session

                    if (data.token) {

                        localStorage.setItem(
                            "maktabToken",
                            data.token
                        );

                    }


                    showMessage(
                        "Login successful! Redirecting...",
                        "success"
                    );


                    // =================================
                    // ROLE BASED REDIRECT
                    // =================================

                    setTimeout(
                        function () {

                            if (
                                role ===
                                "teacher"
                            ) {

                                window.location.href =
                                    "teacher.html";

                            }

                            else if (
                                role ===
                                "admin"
                            ) {

                                window.location.href =
                                    "admin.html";

                            }

                        },
                        700
                    );

                }

                else {

                    throw new Error(
                        data.message ||
                        "Invalid username or password."
                    );

                }

            }

            catch (error) {

                console.error(
                    "Login Error:",
                    error
                );


                showMessage(
                    error.message ||
                    "Unable to connect to login API.",
                    "error"
                );

            }

            finally {

                loginButton.disabled =
                    false;

                loginButton.textContent =
                    "Login";

            }

        }
    );


    // =========================================
    // MESSAGE FUNCTION
    // =========================================

    function showMessage(
        message,
        type
    ) {

        loginMessage.textContent =
            message;

        loginMessage.className =
            "login-message";


        if (type) {

            loginMessage.classList.add(
                type
            );

        }

    }

});