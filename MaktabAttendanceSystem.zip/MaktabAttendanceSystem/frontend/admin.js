document.addEventListener("DOMContentLoaded", function () {

    // =========================================
    // API CONFIGURATION
    // =========================================

    const API_BASE_URL =
        "https://a6ivi274ul.execute-api.ap-south-1.amazonaws.com/prod";


    // =========================================
    // LOGIN PROTECTION
    // =========================================

    const role =
        localStorage.getItem("maktabRole");

    const username =
        localStorage.getItem("maktabUsername");


    if (role !== "admin") {

        window.location.href =
            "login.html";

        return;
    }


    // =========================================
    // ADMIN NAME
    // =========================================

    const adminName =
        document.getElementById("adminName");

    if (adminName && username) {

        adminName.textContent =
            username;
    }


    // =========================================
    // NAVIGATION ELEMENTS
    // =========================================

    const dashboardNav =
        document.getElementById("dashboardNav");

    const attendanceNav =
        document.getElementById("attendanceNav");

    const studentsNav =
        document.getElementById("studentsNav");


    const dashboardSection =
        document.getElementById("dashboardSection");

    const attendanceSection =
        document.getElementById("attendanceSection");

    const studentsSection =
        document.getElementById("studentsSection");


    // =========================================
    // ATTENDANCE ELEMENTS
    // =========================================

    const classSelect =
        document.getElementById("classSelect");

    const dateInput =
        document.getElementById("attendanceDate");

    const loadAttendanceButton =
        document.getElementById("loadAttendanceButton");

    const attendanceCard =
        document.getElementById("attendanceCard");

    const totalRecords =
        document.getElementById("totalRecords");

    const presentCount =
        document.getElementById("presentCount");

    const absentCount =
        document.getElementById("absentCount");

    const attendanceRate =
        document.getElementById("attendanceRate");


    // =========================================
    // STUDENT ELEMENTS
    // =========================================

    const studentClassSelect =
        document.getElementById("studentClassSelect");

    const loadStudentsButton =
        document.getElementById("loadStudentsButton");

    const studentsCard =
        document.getElementById("studentsCard");

    const studentTotal =
        document.getElementById("studentTotal");

    const selectedStudentClass =
        document.getElementById("selectedStudentClass");


    // =========================================
    // ADD STUDENT ELEMENTS
    // =========================================

    const newStudentId =
        document.getElementById("newStudentId");

    const newStudentName =
        document.getElementById("newStudentName");

    const newFormNo =
        document.getElementById("newFormNo");

    const newSerialNo =
        document.getElementById("newSerialNo");

    const newStudentClass =
        document.getElementById("newStudentClass");

    const addStudentButton =
        document.getElementById("addStudentButton");

    const addStudentMessage =
        document.getElementById("addStudentMessage");


    // =========================================
    // LOGOUT
    // =========================================

    const logoutButton =
        document.getElementById("logoutButton");


    if (logoutButton) {

        logoutButton.addEventListener(
            "click",
            function () {

                localStorage.removeItem(
                    "maktabUsername"
                );

                localStorage.removeItem(
                    "maktabRole"
                );

                localStorage.removeItem(
                    "maktabToken"
                );

                window.location.href =
                    "login.html";
            }
        );
    }


    // =========================================
    // TODAY'S DATE
    // =========================================

    const today =
        new Date()
            .toISOString()
            .split("T")[0];


    if (dateInput) {

        dateInput.value =
            today;
    }


    // =========================================
    // NAVIGATION
    // =========================================

    function showSection(section) {

        if (dashboardSection) {

            dashboardSection.style.display =
                "none";
        }

        if (attendanceSection) {

            attendanceSection.style.display =
                "none";
        }

        if (studentsSection) {

            studentsSection.style.display =
                "none";
        }


        if (dashboardNav) {

            dashboardNav.classList.remove(
                "active"
            );
        }

        if (attendanceNav) {

            attendanceNav.classList.remove(
                "active"
            );
        }

        if (studentsNav) {

            studentsNav.classList.remove(
                "active"
            );
        }


        // DASHBOARD

        if (section === "dashboard") {

            if (dashboardSection) {

                dashboardSection.style.display =
                    "block";
            }

            if (dashboardNav) {

                dashboardNav.classList.add(
                    "active"
                );
            }
        }


        // ATTENDANCE

        if (section === "attendance") {

            if (attendanceSection) {

                attendanceSection.style.display =
                    "block";
            }

            if (attendanceNav) {

                attendanceNav.classList.add(
                    "active"
                );
            }
        }


        // STUDENTS

        if (section === "students") {

            if (studentsSection) {

                studentsSection.style.display =
                    "block";
            }

            if (studentsNav) {

                studentsNav.classList.add(
                    "active"
                );
            }
        }
    }


    // =========================================
    // DASHBOARD NAVIGATION
    // =========================================

    if (dashboardNav) {

        dashboardNav.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                showSection(
                    "dashboard"
                );
            }
        );
    }


    // =========================================
    // ATTENDANCE NAVIGATION
    // =========================================

    if (attendanceNav) {

        attendanceNav.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                showSection(
                    "attendance"
                );
            }
        );
    }


    // =========================================
    // STUDENTS NAVIGATION
    // =========================================

    if (studentsNav) {

        studentsNav.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                showSection(
                    "students"
                );
            }
        );
    }


    // =========================================
    // DEFAULT SECTION
    // =========================================

    showSection(
        "dashboard"
    );


    // =========================================
    // LOAD ATTENDANCE BUTTON
    // =========================================

    if (loadAttendanceButton) {

        loadAttendanceButton.addEventListener(
            "click",
            loadAttendance
        );
    }


    // =========================================
    // LOAD ATTENDANCE
    // =========================================

    async function loadAttendance() {

        const selectedClass =
            classSelect
                ? classSelect.value
                : "";

        const selectedDate =
            dateInput
                ? dateInput.value
                : "";


        if (!selectedDate) {

            alert(
                "Please select a date."
            );

            return;
        }


        if (attendanceCard) {

            attendanceCard.innerHTML = `

                <div class="empty-state">

                    <div class="empty-icon">
                        ⏳
                    </div>

                    <h3>
                        Loading attendance...
                    </h3>

                    <p>
                        Please wait.
                    </p>

                </div>
            `;
        }


        if (loadAttendanceButton) {

            loadAttendanceButton.disabled =
                true;

            loadAttendanceButton.textContent =
                "Loading...";
        }


        try {

            let attendanceUrl =
                `${API_BASE_URL}/attendance?date=${encodeURIComponent(
                    selectedDate
                )}`;


            if (selectedClass) {

                attendanceUrl +=
                    `&class=${encodeURIComponent(
                        selectedClass
                    )}`;
            }


            console.log(
                "Attendance API:",
                attendanceUrl
            );


            const response =
                await fetch(
                    attendanceUrl
                );


            const data =
                await response.json();


            console.log(
                "Attendance Response:",
                data
            );


            if (!response.ok) {

                throw new Error(
                    data.message ||
                    `API returned ${response.status}`
                );
            }


            if (!data.success) {

                throw new Error(
                    data.message ||
                    "Unable to load attendance."
                );
            }


            const records =
                data.records || [];


            updateStatistics(
                records
            );


            displayAttendance(
                records,
                selectedClass,
                selectedDate
            );

        }

        catch (error) {

            console.error(
                "Attendance Load Error:",
                error
            );


            if (attendanceCard) {

                attendanceCard.innerHTML = `

                    <div class="empty-state">

                        <div class="empty-icon">
                            ❌
                        </div>

                        <h3>
                            Unable to load attendance
                        </h3>

                        <p>
                            ${escapeHtml(
                                error.message
                            )}
                        </p>

                    </div>
                `;
            }


            if (totalRecords) {

                totalRecords.textContent =
                    "0";
            }


            if (presentCount) {

                presentCount.textContent =
                    "0";
            }


            if (absentCount) {

                absentCount.textContent =
                    "0";
            }


            if (attendanceRate) {

                attendanceRate.textContent =
                    "0%";
            }

        }

        finally {

            if (loadAttendanceButton) {

                loadAttendanceButton.disabled =
                    false;

                loadAttendanceButton.textContent =
                    "🔍 Load Attendance";
            }
        }
    }


    // =========================================
    // ATTENDANCE STATISTICS
    // =========================================

    function updateStatistics(
        records
    ) {

        let present = 0;

        let absent = 0;


        records.forEach(
            function (record) {

                if (
                    record.status ===
                    "Present"
                ) {

                    present++;
                }


                if (
                    record.status ===
                    "Absent"
                ) {

                    absent++;
                }
            }
        );


        if (totalRecords) {

            totalRecords.textContent =
                records.length;
        }


        if (presentCount) {

            presentCount.textContent =
                present;
        }


        if (absentCount) {

            absentCount.textContent =
                absent;
        }


        const total =
            present + absent;


        const rate =
            total > 0
                ? Math.round(
                    (present / total) * 100
                )
                : 0;


        if (attendanceRate) {

            attendanceRate.textContent =
                `${rate}%`;
        }
    }


    // =========================================
    // DISPLAY ATTENDANCE
    // =========================================

    function displayAttendance(
        records,
        selectedClass,
        selectedDate
    ) {

        if (!records.length) {

            attendanceCard.innerHTML = `

                <div class="empty-state">

                    <div class="empty-icon">
                        📋
                    </div>

                    <h3>
                        No attendance found
                    </h3>

                    <p>
                        No attendance records were
                        found for
                        ${escapeHtml(
                            selectedClass ||
                            "all classes"
                        )}
                        on
                        ${escapeHtml(
                            selectedDate
                        )}.
                    </p>

                </div>
            `;

            return;
        }


        let rows = "";


        records.forEach(
            function (record, index) {

                const statusClass =
                    record.status ===
                    "Present"
                        ? "status-present"
                        : "status-absent";


                rows += `

                    <tr>

                        <td>
                            ${index + 1}
                        </td>

                        <td>
                            ${escapeHtml(
                                record.student_id ||
                                "-"
                            )}
                        </td>

                        <td>
                            ${escapeHtml(
                                record.student_name ||
                                "-"
                            )}
                        </td>

                        <td>
                            ${escapeHtml(
                                record.class_name ||
                                "-"
                            )}
                        </td>

                        <td>
                            ${escapeHtml(
                                record.date ||
                                "-"
                            )}
                        </td>

                        <td>

                            <span
                                class="attendance-status ${statusClass}"
                            >
                                ${escapeHtml(
                                    record.status ||
                                    "-"
                                )}
                            </span>

                        </td>

                        <td>
                            ${escapeHtml(
                                record.teacher ||
                                "-"
                            )}
                        </td>

                    </tr>
                `;
            }
        );


        attendanceCard.innerHTML = `

            <div class="attendance-header">

                <div>

                    <h3>
                        Attendance Records
                    </h3>

                    <p>
                        ${escapeHtml(
                            selectedClass ||
                            "All Classes"
                        )}

                        —

                        ${escapeHtml(
                            selectedDate
                        )}
                    </p>

                </div>


                <button
                    type="button"
                    class="primary-button"
                    id="downloadExcelButton"
                >
                    📥 Download Excel
                </button>

            </div>


            <div class="table-container">

                <table id="attendanceTable">

                    <thead>

                        <tr>

                            <th>#</th>

                            <th>
                                Student ID
                            </th>

                            <th>
                                Student Name
                            </th>

                            <th>
                                Class
                            </th>

                            <th>
                                Date
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Teacher
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        ${rows}

                    </tbody>

                </table>

            </div>
        `;


        const downloadButton =
            document.getElementById(
                "downloadExcelButton"
            );


        if (downloadButton) {

            downloadButton.addEventListener(
                "click",
                function () {

                    downloadAttendanceExcel(
                        records,
                        selectedClass,
                        selectedDate
                    );
                }
            );
        }
    }


    // =========================================
    // DOWNLOAD ATTENDANCE EXCEL
    // =========================================

    function downloadAttendanceExcel(
        records,
        selectedClass,
        selectedDate
    ) {

        if (
            typeof XLSX ===
            "undefined"
        ) {

            alert(
                "Excel library could not be loaded. Please check your internet connection."
            );

            return;
        }


        if (
            !records ||
            !records.length
        ) {

            alert(
                "There is no attendance data to download."
            );

            return;
        }


        const excelData =
            records.map(
                function (
                    record,
                    index
                ) {

                    return {

                        "#":
                            index + 1,

                        "Student ID":
                            record.student_id ||
                            "",

                        "Student Name":
                            record.student_name ||
                            "",

                        "Class":
                            record.class_name ||
                            "",

                        "Date":
                            record.date ||
                            "",

                        "Status":
                            record.status ||
                            "",

                        "Teacher":
                            record.teacher ||
                            ""
                    };
                }
            );


        const worksheet =
            XLSX.utils.json_to_sheet(
                excelData
            );


        worksheet["!cols"] = [

            {
                wch: 6
            },

            {
                wch: 16
            },

            {
                wch: 30
            },

            {
                wch: 30
            },

            {
                wch: 15
            },

            {
                wch: 15
            },

            {
                wch: 20
            }
        ];


        const workbook =
            XLSX.utils.book_new();


        XLSX.utils.book_append_sheet(
            workbook,
            worksheet,
            "Attendance"
        );


        let className =
            selectedClass ||
            "All_Classes";


        className =
            className.replace(
                /[^a-zA-Z0-9]+/g,
                "_"
            );


        const fileName =
            `Attendance_${className}_${selectedDate}.xlsx`;


        XLSX.writeFile(
            workbook,
            fileName
        );
    }


    // =========================================
    // LOAD STUDENTS BUTTON
    // =========================================

    if (loadStudentsButton) {

        loadStudentsButton.addEventListener(
            "click",
            loadStudents
        );
    }


    // =========================================
    // LOAD STUDENTS
    // =========================================

    async function loadStudents() {

        const selectedClass =
            studentClassSelect
                ? studentClassSelect.value
                : "";


        if (!selectedClass) {

            alert(
                "Please select a class."
            );

            return;
        }


        if (studentsCard) {

            studentsCard.innerHTML = `

                <div class="empty-state">

                    <div class="empty-icon">
                        ⏳
                    </div>

                    <h3>
                        Loading students...
                    </h3>

                    <p>
                        Please wait.
                    </p>

                </div>
            `;
        }


        if (loadStudentsButton) {

            loadStudentsButton.disabled =
                true;

            loadStudentsButton.textContent =
                "Loading...";
        }


        try {

            const studentsUrl =
                `${API_BASE_URL}/students?class=${encodeURIComponent(
                    selectedClass
                )}`;


            console.log(
                "Students API:",
                studentsUrl
            );


            const response =
                await fetch(
                    studentsUrl
                );


            const data =
                await response.json();


            console.log(
                "Students Response:",
                data
            );


            if (!response.ok) {

                throw new Error(
                    data.message ||
                    `Students API returned ${response.status}`
                );
            }


            if (!data.success) {

                throw new Error(
                    data.message ||
                    "Unable to load students."
                );
            }


            const students =
                data.students || [];


            if (studentTotal) {

                studentTotal.textContent =
                    students.length;
            }


            if (selectedStudentClass) {

                selectedStudentClass.textContent =
                    selectedClass;
            }


            displayStudents(
                students,
                selectedClass
            );

        }

        catch (error) {

            console.error(
                "Students Load Error:",
                error
            );


            if (studentTotal) {

                studentTotal.textContent =
                    "0";
            }


            if (selectedStudentClass) {

                selectedStudentClass.textContent =
                    selectedClass;
            }


            if (studentsCard) {

                studentsCard.innerHTML = `

                    <div class="empty-state">

                        <div class="empty-icon">
                            ❌
                        </div>

                        <h3>
                            Unable to load students
                        </h3>

                        <p>
                            ${escapeHtml(
                                error.message
                            )}
                        </p>

                    </div>
                `;
            }

        }

        finally {

            if (loadStudentsButton) {

                loadStudentsButton.disabled =
                    false;

                loadStudentsButton.textContent =
                    "👨‍🎓 Load Students";
            }
        }
    }


    // =========================================
    // DISPLAY STUDENTS
    // =========================================

    function displayStudents(
        students,
        selectedClass
    ) {

        if (!students.length) {

            studentsCard.innerHTML = `

                <div class="empty-state">

                    <div class="empty-icon">
                        👨‍🎓
                    </div>

                    <h3>
                        No students found
                    </h3>

                    <p>
                        No students were found
                        in
                        ${escapeHtml(
                            selectedClass
                        )}.
                    </p>

                </div>
            `;

            return;
        }


        let rows = "";


        students.forEach(
            function (
                student,
                index
            ) {

                const studentId =
                    student.student_id ||
                    "";


                rows += `

                    <tr>

                        <td>
                            ${index + 1}
                        </td>

                        <td>
                            ${escapeHtml(
                                student.form_no ||
                                "-"
                            )}
                        </td>

                        <td>
                            ${escapeHtml(
                                student.student_id ||
                                "-"
                            )}
                        </td>

                        <td>
                            ${escapeHtml(
                                student.student_name ||
                                "-"
                            )}
                        </td>

                        <td>
                            ${escapeHtml(
                                student.class_name ||
                                selectedClass
                            )}
                        </td>

                        <td>

                            <button
                                type="button"
                                class="delete-student-button"
                                data-student-id="${escapeHtml(
                                    studentId
                                )}"
                                style="
                                    background:#dc3545;
                                    color:white;
                                    border:none;
                                    padding:8px 14px;
                                    border-radius:6px;
                                    cursor:pointer;
                                    font-weight:600;
                                "
                            >
                                🗑️ Delete
                            </button>

                        </td>

                    </tr>
                `;
            }
        );


        studentsCard.innerHTML = `

            <div class="attendance-header">

                <div>

                    <h3>
                        ${escapeHtml(
                            selectedClass
                        )}
                    </h3>

                    <p>
                        Total Students:
                        ${students.length}
                    </p>

                </div>

            </div>


            <div class="table-container">

                <table>

                    <thead>

                        <tr>

                            <th>
                                #
                            </th>

                            <th>
                                Form No.
                            </th>

                            <th>
                                Student ID
                            </th>

                            <th>
                                Student Name
                            </th>

                            <th>
                                Class
                            </th>

                            <th>
                                Action
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        ${rows}

                    </tbody>

                </table>

            </div>
        `;


        // =====================================
        // DELETE BUTTON EVENTS
        // =====================================

        const deleteButtons =
            studentsCard.querySelectorAll(
                ".delete-student-button"
            );


        deleteButtons.forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function () {

                        const studentId =
                            button.getAttribute(
                                "data-student-id"
                            );


                        deleteStudent(
                            studentId,
                            button
                        );
                    }
                );
            }
        );
    }


    // =========================================
    // DELETE STUDENT
    // =========================================

    async function deleteStudent(
        studentId,
        button
    ) {

        if (!studentId) {

            alert(
                "Student ID is missing."
            );

            return;
        }


        // =====================================
        // CONFIRMATION
        // =====================================

        const confirmed =
            confirm(
                `Are you sure you want to delete student "${studentId}"?\n\nThis action cannot be undone.`
            );


        if (!confirmed) {

            return;
        }


        // =====================================
        // DISABLE BUTTON
        // =====================================

        if (button) {

            button.disabled =
                true;

            button.textContent =
                "Deleting...";

            button.style.opacity =
                "0.6";

            button.style.cursor =
                "not-allowed";
        }


        try {

            // =================================
            // DELETE API
            // =================================

            const deleteUrl =
                `${API_BASE_URL}/students?student_id=${encodeURIComponent(
                    studentId
                )}`;


            console.log(
                "Delete Student API:",
                deleteUrl
            );


            const response =
                await fetch(
                    deleteUrl,
                    {
                        method:
                            "DELETE",

                        headers: {
                            "Content-Type":
                                "application/json"
                        }
                    }
                );


            const data =
                await response.json();


            console.log(
                "Delete Student Response:",
                data
            );


            // =================================
            // API ERROR
            // =================================

            if (!response.ok) {

                throw new Error(
                    data.message ||
                    `Delete API returned ${response.status}`
                );
            }


            if (!data.success) {

                throw new Error(
                    data.message ||
                    "Unable to delete student."
                );
            }


            // =================================
            // SUCCESS
            // =================================

            alert(
                "✅ Student deleted successfully."
            );


            // =================================
            // REFRESH STUDENT LIST
            // =================================

            await loadStudents();

        }

        catch (error) {

            console.error(
                "Delete Student Error:",
                error
            );


            alert(
                `❌ Unable to delete student.\n\n${error.message}`
            );


            // Restore button

            if (button) {

                button.disabled =
                    false;

                button.textContent =
                    "🗑️ Delete";

                button.style.opacity =
                    "1";

                button.style.cursor =
                    "pointer";
            }
        }
    }


    // =========================================
    // ADD STUDENT BUTTON
    // =========================================

    if (addStudentButton) {

        addStudentButton.addEventListener(
            "click",
            addStudent
        );
    }


    // =========================================
    // ADD STUDENT
    // =========================================

    async function addStudent() {

        const studentId =
            newStudentId
                ? newStudentId.value.trim()
                : "";


        const studentName =
            newStudentName
                ? newStudentName.value.trim()
                : "";


        const formNo =
            newFormNo
                ? newFormNo.value.trim()
                : "";


        const serialNo =
            newSerialNo
                ? newSerialNo.value.trim()
                : "";


        const className =
            newStudentClass
                ? newStudentClass.value.trim()
                : "";


        // =====================================
        // VALIDATION
        // =====================================

        if (!studentId) {

            alert(
                "Please enter Student ID."
            );

            if (newStudentId) {

                newStudentId.focus();
            }

            return;
        }


        if (!studentName) {

            alert(
                "Please enter Student Name."
            );

            if (newStudentName) {

                newStudentName.focus();
            }

            return;
        }


        if (!formNo) {

            alert(
                "Please enter Form Number."
            );

            if (newFormNo) {

                newFormNo.focus();
            }

            return;
        }


        if (!serialNo) {

            alert(
                "Please enter Serial Number."
            );

            if (newSerialNo) {

                newSerialNo.focus();
            }

            return;
        }


        if (!className) {

            alert(
                "Please select a class."
            );

            if (newStudentClass) {

                newStudentClass.focus();
            }

            return;
        }


        // =====================================
        // DISABLE BUTTON
        // =====================================

        addStudentButton.disabled =
            true;

        addStudentButton.textContent =
            "Adding...";


        try {

            const studentData = {

                student_id:
                    studentId,

                student_name:
                    studentName,

                form_no:
                    formNo,

                serial_no:
                    serialNo,

                class_name:
                    className
            };


            console.log(
                "Adding Student:",
                studentData
            );


            // =================================
            // POST /students
            // =================================

            const response =
                await fetch(
                    `${API_BASE_URL}/students`,
                    {
                        method:
                            "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body:
                            JSON.stringify(
                                studentData
                            )
                    }
                );


            const data =
                await response.json();


            console.log(
                "Add Student Response:",
                data
            );


            if (!response.ok) {

                throw new Error(
                    data.message ||
                    `API returned ${response.status}`
                );
            }


            if (!data.success) {

                throw new Error(
                    data.message ||
                    "Unable to add student."
                );
            }


            // =================================
            // SUCCESS
            // =================================

            alert(
                "✅ Student added successfully!"
            );


            if (addStudentMessage) {

                addStudentMessage.style.display =
                    "block";

                addStudentMessage.style.color =
                    "green";

                addStudentMessage.textContent =
                    "✅ Student added successfully.";
            }


            // =================================
            // CLEAR FORM
            // =================================

            if (newStudentId) {

                newStudentId.value =
                    "";
            }


            if (newStudentName) {

                newStudentName.value =
                    "";
            }


            if (newFormNo) {

                newFormNo.value =
                    "";
            }


            if (newSerialNo) {

                newSerialNo.value =
                    "";
            }


            if (newStudentClass) {

                newStudentClass.value =
                    "";
            }


            // =================================
            // REFRESH CLASS STUDENTS
            // =================================

            if (
                studentClassSelect &&
                studentClassSelect.value ===
                    className
            ) {

                await loadStudents();
            }

        }

        catch (error) {

            console.error(
                "Add Student Error:",
                error
            );


            if (addStudentMessage) {

                addStudentMessage.style.display =
                    "block";

                addStudentMessage.style.color =
                    "red";

                addStudentMessage.textContent =
                    `❌ ${error.message}`;
            }


            alert(
                `Unable to add student:\n\n${error.message}`
            );
        }


        finally {

            addStudentButton.disabled =
                false;

            addStudentButton.textContent =
                "➕ Add Student";
        }
    }


    // =========================================
    // HTML ESCAPE
    // =========================================

    function escapeHtml(
        value
    ) {

        const div =
            document.createElement(
                "div"
            );


        div.textContent =
            value ?? "";


        return div.innerHTML;
    }


});